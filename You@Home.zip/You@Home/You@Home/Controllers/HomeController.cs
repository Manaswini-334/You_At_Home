﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using You_Home.Models;
namespace You_Home.Controllers
{
    public class HomeController : Controller
    { 
       /* public ActionResult City()
        {
            SqlOperations Con = new SqlOperations();
            City ForCity = new City();
            ForCity.CityList = new SelectList(Con.GetCityList(), "CityId", "Name");
            return View("Index",ForCity);
        }*/
        public ActionResult DropDownLists()
        {
            SqlOperations Con = new SqlOperations();
            ViewModelForLists Obj = new ViewModelForLists();
            var City = Con.GetCityList();
            var Area = Con.GetAreaList();
            var PropertyType = Con.GetPropertyTypeList();
            foreach(var item in City)
            {
                Obj.CityList.Add(item); 
            }
            foreach (var item in Area)
            {
                Obj.AreaList.Add(item);
            }
            foreach (var item in PropertyType)
            {
                Obj.PropertyTypeList.Add(item);
            }
            return View(Obj);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult News()
        {
            return View("News");
        }
    }
}