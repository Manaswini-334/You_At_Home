﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using You_Home.Models;
using Dapper;
using System.IO;
namespace You_Home.Controllers
{
    public class RentController : Controller
    {
        // GET: Rent
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["You@Home"].ToString());
        public int PropIdVal;
        public ActionResult RentProperty()
        {
            SqlOperations Con = new SqlOperations();
            RentProperty Obj = new RentProperty();
            var City = Con.GetCityList();
            var Area = Con.GetAreaList();
            var Pincode = Con.GetPincodeList();
            var PropertyType = Con.GetPropertyTypeList();
            var Facility = Con.GetFacilityList();
            foreach (var item in City)
            {
                Obj.CityList.Add(item);
            }
            foreach (var item in Area)
            {
                Obj.AreaList.Add(item);
            }
            foreach (var item in PropertyType)
            {
                Obj.PropertyTypeList.Add(item);
            }
            foreach (var item in Pincode)
            {
                Obj.PincodeList.Add(item);
            }
            foreach (var item in Facility)
            {
                Obj.FacilityList.Add(item);
            }
            
            return View(Obj);
        }
        [HttpPost]
        public ActionResult RentProperty(RentProperty Property)
        {
            Property.CityId = int.Parse(Request.Form["CityList"].ToString());
            Property.AreaId = int.Parse(Request.Form["AreaList"].ToString());
            Property.PincodeId = int.Parse(Request.Form["PincodeList"].ToString());
            Property.PropertyTypeId = int.Parse(Request.Form["PropertyTypeList"].ToString());
            if (Property.AC == null) 
            {
                Property.AC = " ";
            }
            else
            { 
                Property.AC = Request.Form["AC"].ToString(); 
            }

            if (Property.Couch == null)
            {
                Property.Couch = " ";
            }
            else
            {
                Property.Couch = Request.Form["Couch"].ToString();
            }
            if (Property.Refrigerator == null)
            {
                Property.Refrigerator = " ";
            }
            else
            {
                Property.Refrigerator = Request.Form["Refrigerator"].ToString();
            }
            if (Property.Wifi == null)
            {
                Property.Wifi = " ";
            }
            else
            {
                Property.Wifi = Request.Form["Wifi"].ToString();
            }
            SqlOperations Sopr = new SqlOperations();
            Sopr.SessionEmail = (string)Session["SignInEmail"];
            Sopr.AddValuesInRentProperty(Property);
            Sopr.GetRentPropertyIdAndInsertInTables(Property);
            return RedirectToAction("UploadImage");
        }
        [HttpGet]
        public ActionResult NewArea()
        {
            SqlOperations Con = new SqlOperations();
            Area Obj = new Area();
            var City = Con.GetCityList();
            foreach (var item in City)
            {
                Obj.CityList.Add(item);
            }
            return View(Obj);
        }
        [HttpPost]
        public ActionResult NewArea(Area area)
        {
            area.CityId = int.Parse(Request.Form["CityList"].ToString());
            SqlOperations sopr = new SqlOperations();
            sopr.AddValuesInArea(area);
            return RedirectToAction("RentProperty");

        }
        
        [HttpGet]
        public ActionResult NewPincode()
        {
            SqlOperations Con = new SqlOperations();
            Pincode Obj = new Pincode();
            var City = Con.GetCityList();
            var Area = Con.GetAreaList();
            foreach (var item in City)
            {
                Obj.CityList.Add(item);
            }
            foreach (var item in Area)
            {
                Obj.AreaList.Add(item);
            }
            return View(Obj);
        }
        [HttpPost]
        public ActionResult NewPincode(Pincode Pin)
        {
            Pin.AreaId = int.Parse(Request.Form["AreaList"].ToString());
            SqlOperations sopr = new SqlOperations();
            sopr.AddValuesInPincode(Pin);
            return RedirectToAction("RentProperty");

        }
         public ActionResult OwnerRentProperty()
         {
             PropertyOfOwner Property = new PropertyOfOwner();
             SqlOperations sopr = new SqlOperations();
             sopr.SessionEmail = (string)Session["SignInEmail"];
             //int[] array = new int[10];
             //Image Image = new Image();  
             //sopr.GetPropertyId();
             //array = sopr.GetPropertyId().ToArray();
             //sopr.PropertyId = PropIdVal;
             return View( sopr.ShowListOfOwnerProperty());
             
         }
         public ActionResult PartialForImage(int id)
         {
             SqlOperations sopr = new SqlOperations();
             sopr.SessionEmail = (string)Session["SignInEmail"];
             sopr.PropertyIdForImg = id;
             return PartialView("~/Views/Rent/PartialForImage.cshtml", sopr.ShowImageOfOwnerProperty());
         }

         [HttpGet]
         public ActionResult UploadImage()
         {
             SqlOperations scon = new SqlOperations();
             scon.SessionEmail = (string)Session["SignInEmail"];
             ImageOfProperty ObjImage = new ImageOfProperty();
             var OwnerProperties = scon.GetPropertyList();
             foreach (var item in OwnerProperties)
             {
                 ObjImage.PropertyList.Add(item);
             }
             return View(ObjImage);
         }

         [HttpPost]
         public ActionResult UploadImage(HttpPostedFileBase file)
         {
             ImageOfProperty ImageObj = new ImageOfProperty();
             SqlOperations scon = new SqlOperations();
             if (file == null && ImageObj.PropertyId==0)
                 {
                     ModelState.AddModelError("file", "You need to upload a image before you click upload.");
                     ModelState.AddModelError("file", "You need to Log in to your account before you upload an image.");
                     var OwnerProperties = scon.GetPropertyList();
                     foreach (var item in OwnerProperties)
                     {
                         ImageObj.PropertyList.Add(item);
                     }
                     return View(ImageObj);
                 }
                 else if (file.ContentLength > 0)
                 { 
                     string[] AllowedFileExtensions = new string[] { ".jpg", ".gif", ".png", ".pdf" };

                     if (!AllowedFileExtensions.Contains(file.FileName.Substring(file.FileName.LastIndexOf('.'))))
                     {
                         ModelState.AddModelError("file", "Please upload image of type: " + string.Join(", ",AllowedFileExtensions));
                     }

                     else
                     {
                         SqlOperations sopr = new SqlOperations();
                         ImageOfProperty Image = new ImageOfProperty();
                         Image.PropertyId = int.Parse(Request.Form["PropertyList"].ToString());
                         sopr.SessionEmail = (string)Session["SignInEmail"];
                         Image.ImageName = Path.GetFileName(file.FileName);
                         Image.Url = Path.Combine(Server.MapPath("~/PropertyImages"), Image.ImageName);
                         file.SaveAs(Image.Url);
                         sopr.InsertImage(Image);
                         ViewBag.Message = "File uploaded successfully. File Name : " + Image.ImageName;
                     }
                 }
             return RedirectToAction("OwnerRentProperty");
             }
            
         
        
    }
}