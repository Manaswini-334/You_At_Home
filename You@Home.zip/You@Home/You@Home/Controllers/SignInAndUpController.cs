﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using You_Home.Models;
using Dapper;

namespace You_Home.Controllers
{
    public class SignInAndUpController : Controller
    { 
        public string MailCheck;
        public ActionResult SignIn()
        {  
            return View();
        }
        [HttpPost]
        public ActionResult SignIn(SignIn Sign)
        {

            Sign.SignInEmail = Request["SignInEmail"];
            Sign.SignInPassword = Request["SignInPassword"];
            SqlOperations sopr = new SqlOperations();
            sopr.CheckSignIn(Sign);
            sopr.CheckOwnerOrTanent(Sign);
            if (sopr.VarForCheckSign == Sign.SignInPassword)
            {
                Session["UserType"] = Sign.UserTypeId;
                Session["SignInEmail"] = Sign.SignInEmail;
                //MailCheck = (string)Session["SignInEmail"];
                ViewBag.Message = Session["SignInEmail"].ToString();
                return RedirectToAction("DropDownLists", "Home", new { area = "" });
            }
            else
            {
                ViewBag.Message = "Your Email or Password You Typed is Not Matching !!! ";
                return View();
            }

        }
        public ActionResult SignOut()
        {
            Session.Abandon();
            return RedirectToAction("DropDownLists", "Home", new { area = "" });
        }
         [HttpGet]
        public ActionResult SignUp()
        {
            SqlOperations Con = new SqlOperations();
            SignUp Obj = new SignUp();
            var City = Con.GetCityList();
            var Area = Con.GetAreaList();
            var UserType = Con.GetUserTypeList();
            foreach(var item in City)
            {
                Obj.CityList.Add(item); 
            }
            foreach (var item in Area)
            {
                Obj.AreaList.Add(item);
            }
            foreach (var item in UserType)
            {
                Obj.UserTypeList.Add(item);
            }
            return View(Obj);
        }
        [HttpPost]
        public ActionResult SignUp(SignUp User)
        {
            User.CityId = int.Parse(Request.Form["CityList"].ToString());
            User.AreaId = int.Parse(Request.Form["AreaList"].ToString());
            User.UserTypeId = int.Parse(Request.Form["UserTypeList"].ToString());
            Session["UserType"] = User.UserTypeId;
            SqlOperations Sopr = new SqlOperations();
            Sopr.AddValuesInUser(User);
            if (User.UserTypeId == 1)
            {
                Sopr.AddValuesInOwner(User);
            }
            else 
            {
                Sopr.AddValuesInTenant(User);
            }
            return RedirectToAction("SignIn");
        }


        [HttpGet]
        public ActionResult NewArea()
        {
            SqlOperations Con = new SqlOperations();
            Area Obj = new Area();
            var City = Con.GetCityList();
            foreach (var item in City)
            {
                Obj.CityList.Add(item);
            }
            return View(Obj);
        }
        [HttpPost]
        public ActionResult NewArea(Area area)
        {
            area.CityId = int.Parse(Request.Form["CityList"].ToString());
            SqlOperations Sopr = new SqlOperations();
            Sopr.AddValuesInArea(area);
            return RedirectToAction("SignUp");

        }
         
    }
}