﻿$(function () {
    $("#SumbitProperty").click(function () {

        var PName = $('#PropertyName').val();
        var HouseNo = $('#HouseNo').val();
        var City = $('#CityList').val();
        var Area = $('#AreaList').val();
        var PropertyType = $('#PropertyTypeList').val();
        var Pin = $('#PincodeList').val();
        var Bedroom = $('#Bedroom').val();
        var Hall = $('#Hall').val();
        var Kitchen = $('#Kitchen').val();
        var Bathroom = $('#Bathroom').val();
        var Ac = $('#AC').val();
        var Couch = $('#Couch').val();
        var Refrigerator = $('#Refrigerator').val();
        var Wifi = $('#Wifi').val();
        var RentAmout = $('#RentAmout').val();
        if (PName == "") {
            alert("Enter the name of the house");
            return false;
        }
        else if (HouseNo == "") {
            alert("U must have to put your House Number!!!");
            return false;
        }
        else if (HouseNo.length < 2) {
            alert("Incorrect House Number, Example : ac-12000 or ac12332 !!!");
            return false;
        }
        else if (City == "") {
            alert(" Select the City where the house is At !!!");
            return false;
        }
        else if (Area == "") {
            alert(" Select Your Area  where the house is At !!!");
            return false;
        }
        else if (PropertyType == "") {
            alert(" Which type of property your house is ?");
            return false;
        }
        else if (Pin == "") {
            alert(" Enter pincode !!!");
            return false;
        }
        else if (Bedroom == "") {
            alert(" Enter numbers of Bedrooms your house have !!!");
            return false;
        }
        else if (isNaN(Bedroom) == true) {
            alert(" Enter numbers only in Bedroom field !!!");
            return false;
        }
        else if (Hall == "") {
            alert(" Enter numbers of Halls your house have  !!!");
            return false;
        }
        else if (isNaN(Hall) == true) {
            alert(" Enter numbers only in Hall field !!!");
            return false;
        }
        else if (Kitchen == "") {
            alert(" Enter numbers of Kitchen your house have !!!");
            return false;
        }
        else if (isNaN(Bedroom) == true) {
            alert(" Enter numbers only in Bedroom field!!!");
            return false;
        }
        else if (Bathroom == "") {
            alert(" Enter numbers of Bathroom your house have !!!");
            return false;
        }
        
        else if (isNaN(Bedroom) == true) {
            alert(" Enter numbers only in Bedroom field !!!");
            return false;
        }
        else if (RentAmout == "" || RentAmout == 0.00 || RentAmout == 0) {
            alert(" Is This House for FREE !!!  ;) , If Not then enter the rent amount .");
            return false;
        }
        return true;

    });

});

 $(function () {
     $('#UploadImage').click(function ()
    {
         var Image = $('#ImageToUpload').val();
         var Property = $('#PropertyList').val();
         if (Property == "")
         {
             alert("Choose Your Property name where you want to store the image");
         }
        if (Image == "")
        {
            alert(" Upload a file then click the 'Upload' button.");
            return false;
        }
        else
        return true;
    }); 

});

$(function () {
    $("#Skip").click(function () {
        $('#ImageToUpload').val() == "No Image";
    });
});