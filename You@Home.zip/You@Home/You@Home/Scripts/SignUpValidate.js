﻿$(function () {
    $("#SubmitSignUp").click(function ()
    {
        
        var Name = $('#FullName').val();
        var UserType = $('#UserTypeList').val();
        var Email = $('#Email').val();
        var password = $('#Password').val();
        var City = $('#CityList').val();
        var Area = $('#AreaList').val();
        var MobileNumber = $('#MobileNumber').val();
        var Emailformat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (UserType == "")
        {
            alert(" Are you a OWNER or TENANT ?");
            return false;
        }
        else if (Name == "")
        {
            alert("U must have to put your name!!!");
            return false;
        }
        else if (Name.length <= 5)
        {
            alert("Enter your Full Name not Nick Name!!!");
            return false;
        }
        else if (Name == " ") {
            alert("space is not allowed!!!");
            return false;
        }
        else if (/[^a-zA-Z .]/.test(Name)) {
            alert("Enter Only Characters in Name field!!!");
            return false;
        }
        else if (Email == "" || !Emailformat.test(Email)) {
            alert("Enter a valid Email Id !!!");
            return false;
        }
        else if (password == "") {
            alert("Your Password Fiels Is Empty !!!");
            return false;
        }
        else if (password.length < 8) {
            alert("Your Password Must Be 8 or More Than 8 Characters !!!");
            return false;
        }
        else if (City == "")
        {
            alert(" Select Your City !!!");
            return false;
        }
        else if (Area == "") {
            alert(" Select Your Area !!!");
            return false;
        }
        else if (MobileNumber.length < 10)
        {
            alert("An Example of the format : 8895****** And Minimum Length is 10");
            return false;
        }
        return true;
        
    });

});

$(function () {
    $("#SubmitSignIn").click(function () {

        var Email = $('#SignInEmail').val();
        var password = $('#SignInPassword').val();
        var Emailformat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (Email == "" || !Emailformat.test(Email)) {
            alert("Not a valid Email Id !!!");
            return false;
        }
        else if (password == "") {
            alert("Enter Your Password !!!");
            return false;
        }
        
        else
        {
            Session["SignInEmail"] = Email;
            return true;
        }
    });

});

$(function () {
    $("#UploadNewArea").click(function () {

        var City = $('#NewAreaCity').val();
        var NewArea = $('#Name').val();
        if (City == "") {
            alert("Choose The City Where Your Area Is Situated!!!");
            return false;
        }
        else if (NewArea == "") {
            alert("You Need To Enter Your New Area's Name !!!");
            return false;
        }
        return true;

    });

});
