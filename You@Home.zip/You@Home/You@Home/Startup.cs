﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(You_Home.Startup))]
namespace You_Home
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
