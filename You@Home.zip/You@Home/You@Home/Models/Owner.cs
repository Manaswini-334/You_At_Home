﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace You_Home.Models
{
    public class Owner
    {
        
            public int UserId { get; set; }
    }
}