﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace You_Home.Models
{
    public class RentProperty
    {
         [Required(ErrorMessage = "City is required")]
        public int CityId { get; set; }
        [Required(ErrorMessage = "Area is required")]
        public int AreaId { get; set; }
        public int PropertyId { get; set; }
        public int PropertyTypeId { get; set; }
        public int PincodeId { get; set; }
        public int OwnerId { get; set; }
        public string Facility { get; set; }
        public string AC{ get; set; }
        public string Couch { get; set; }
        public string  Refrigerator { get; set; }
        public string Wifi { get; set; }
        [Required(ErrorMessage = "Property Name Required")]
        public string Name { get; set; }
         [Required(ErrorMessage = "Must give the house number")]
        public string HouseNumber { get; set; }
        [Required(ErrorMessage = "Enter Number Of BedRooms your property have")]
        public string Bedroom { get; set; }
        [Required(ErrorMessage = "Enter Number Of Halls your property have")]
        public string Hall { get; set; }
        [Required(ErrorMessage = "Enter Number Of Kitchens your property have")]
        public string kitchen { get; set; }
        public string Bathroom { get; set; }
        [Required(ErrorMessage = "Enter the rent amount")]
        public float RentAmount { get; set; }
         [Required(ErrorMessage = "City is required")]
        public List<City> CityList = new List<City>();
         
        public List<Area> AreaList = new List<Area>();
        public List<PropertyType> PropertyTypeList = new List<PropertyType>();
        public List<Pincode> PincodeList = new List<Pincode>();
        public List<Facility> FacilityList = new List<Facility>();
    }
}
