﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace You_Home.Models
{
    public class PropertyOfOwner
    {
         public int PropertyId { get; set; }
         public string PropertyName {get; set; }
         public string PropertyType {get; set; }
         public string HouseNumber {get; set; }
         public int Bedroom {get; set; }
         public int Hall {get; set; }
         public int kitchen {get; set; }
         public int Bathroom {get; set; }
         public string City {get; set; }
         public string Area {get; set; }
         public string Pincode {get; set; }
         public string Facility {get; set; }
         public float RentAmount {get; set; }
         public string ImageName { get; set; }
         public string Url { get; set; }
         IEnumerable<Image> ImageDetails { get; set; }
         
         
    }
}