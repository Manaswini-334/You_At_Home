﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace You_Home.Models
{
    public class SignUp
    {
        [Required(ErrorMessage = "User Type Required")]
        public int UserTypeId { get; set; }
        [Required(ErrorMessage = "User Name Required")]
        public string FullName { get; set; }
        [Required(ErrorMessage = "Email Required")]
        [RegularExpression(@"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$")]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [StringLength(30,MinimumLength = 8, ErrorMessage = "Minimun Length is 8")]
        public string Password { get; set; }
        public int CityId { get; set; }
        public int AreaId { get; set; }
        [Required(ErrorMessage = "User Type Required")]
        public List<UserType> UserTypeList = new List<UserType>();
        [Required(ErrorMessage = "City is required")]
        public List<City> CityList = new List<City>();
        public List<Area> AreaList = new List<Area>();
        [StringLength(10, MinimumLength = 10, ErrorMessage = "An Example of the format : 8895****** And Minimum Length is 10")]
        public string MobileNumber { get; set; }
    }
}