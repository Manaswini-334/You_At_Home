﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace You_Home.Models
{
    public class Area
    {
        public int AreaId { get; set; }
        public int CityId { get; set;}
        public string Name { get; set; }
        public List<City> CityList = new List<City>();
    }
}