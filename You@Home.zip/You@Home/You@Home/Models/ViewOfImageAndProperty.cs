﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace You_Home.Models
{
    public class ViewOfImageAndProperty
    {
        public IEnumerable<Image> ImageVal { get; set; }
        public IEnumerable<PropertyOfOwner> PropEnum { get; set; }
    }
}