﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace You_Home.Models
{
    public class ViewModelForLists
    {
        public List<City> CityList = new List<City>();
        public List<Area> AreaList = new List<Area>();
        public List<PropertyType> PropertyTypeList = new List<PropertyType>();
       
    }
}