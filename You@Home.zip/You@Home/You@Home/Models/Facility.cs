﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace You_Home.Models
{
    public class Facility
    {
        public int FacilityId { get; set; }
        public string Name { get; set; }
    }
}