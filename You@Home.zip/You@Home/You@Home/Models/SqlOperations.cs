﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using You_Home.Controllers;

namespace You_Home.Models
{
    public class SqlOperations
    {
        
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["You@Home"].ToString());
        public string VarForCheckSign;
        public string SessionEmail;
        public string PropertyNameInSql;
        public int PropertyIdForImg;
        public int PropertyId;
        public IEnumerable<City> GetCityList()
        {
            string Cquery = "SELECT CityId,Name FROM You@Home.dbo.City;";
            var Cresult = con.Query<City>(Cquery);
            return Cresult;
        }
        public IEnumerable<Area> GetAreaList()
        {

            string Aquery = "SELECT AreaId, CONCAT(Area.Name,', ',City.Name) as Name FROM dbo.Area INNER JOIN dbo.City ON(Area.CityId = City.CityId)";
            var Aresult = con.Query<Area>(Aquery);
            return Aresult;
        }
        public IEnumerable<Pincode> GetPincodeList()
        {

            string Pquery = "SELECT PincodeId, CONCAT(Area.Name,', ',Pincode.Value) as Value FROM dbo.Area INNER JOIN dbo.Pincode ON(Area.AreaId = Pincode.AreaId)";
            var Presult = con.Query<Pincode>(Pquery);
            return Presult;
        }
        public IEnumerable<PropertyType> GetPropertyTypeList()
        {
            string Pquery = "SELECT PropertyTypeId,Name FROM You@Home.dbo.PropertyType;";
            var Presult = con.Query<PropertyType>(Pquery);
            return Presult;
        }
        public IEnumerable<UserType> GetUserTypeList()
        {
            string Prquery = "SELECT UserTypeId,Name FROM You@Home.dbo.userType;";
            var Presult = con.Query<UserType>(Prquery);
            return Presult;
        }
        public IEnumerable<Facility> GetFacilityList()
        {
            string Fquery = "SELECT FacilityId,Name FROM You@Home.dbo.Facility;";
            var Fresult = con.Query<Facility>(Fquery);
            return Fresult;
        }
        public string AddValuesInUser(SignUp User)
        {
            string InsertQuery = "insert into dbo.UserInformation(FullName, Email, Password, CityId, AreaId, UserTypeId, MobileNumber) " + "values(@FullName, @Email, @Password, @CityId, @AreaId, @UserTypeId, @MobileNumber);";
            con.Execute(InsertQuery, new { User.FullName, User.Email, User.Password, User.CityId, User.AreaId, User.UserTypeId, User.MobileNumber });
            return "Success";
        }
        public string AddValuesInArea(Area area)
        {
            string InsertQuery = "insert into dbo.Area( CityId, Name) " + "values( @CityId, @Name);";
            con.Open();
            con.Execute(InsertQuery, new { area.CityId, area.Name });
            return "Inserted";

        }
        public string AddValuesInRentProperty(RentProperty Property)
        {
            string InsertQuery = "insert into dbo.Property( Name, PropertyTypeId, HouseNumber, Bedroom, Hall, kitchen, Bathroom, PincodeId,RentAmount) " + "values( @Name, @PropertyTypeId, @HouseNumber, @Bedroom, @Hall, @kitchen, @Bathroom, @PincodeId, @RentAmount);";
            con.Open();
            con.Execute(InsertQuery, new { Property.Name, Property.PropertyTypeId, Property.HouseNumber, Property.Bedroom, Property.Hall, Property.kitchen, Property.Bathroom, Property.PincodeId, Property.RentAmount });
            return "Inserted";

        }
        public string AddValuesInOwner(SignUp owner)
        {
           // string SelectQuery = "select max(userid) from dbo.UserInformation where userTypeId=1;";

            SqlCommand SelectQuery = new SqlCommand("select max(userid) from dbo.UserInformation where userTypeId=1;", con);
            con.Open();
            owner.UserTypeId = (int)SelectQuery.ExecuteScalar();
            string InsertQuery = "insert into dbo.Owner(UserId) " + "values( @UserTypeId);";
           
            con.Execute(InsertQuery, new { owner.UserTypeId });
            return "Inserted";
        }
        public string CheckOwnerOrTanent(SignIn check)
        {
            int Val = 0;
            SqlCommand SelectQuery = new SqlCommand("select UserTypeId from dbo.UserInformation where (Email = '"+ check.SignInEmail + "') ", con);
            string value = (string)SelectQuery.ExecuteScalar();
            int.TryParse(value, out Val);
            check.UserTypeId = Val;
            return "Inserted";
        }
        public string AddValuesInTenant(SignUp tenant)
        {
            SqlCommand SelectQuery = new SqlCommand("select max(userid) from dbo.UserInformation where userTypeId=2;", con);
            con.Open();
            tenant.UserTypeId = (int)SelectQuery.ExecuteScalar();
            string InsertQuery = "insert into dbo.Tenant(UserId) " + "values( @UserTypeId);";
            con.Execute(InsertQuery, new { tenant.UserTypeId });
            return "Inserted";
        }
        public string GetRentPropertyIdAndInsertInTables(RentProperty rent)
        {
            SignIn Sign = new SignIn();
           
            SqlCommand SelectQuery = new SqlCommand("select max(PropertyId) from dbo.Property;", con);
            rent.PropertyId = (int)SelectQuery.ExecuteScalar();

            SqlCommand SelectQuery1 = new SqlCommand("select OwnerId from dbo.Owner Inner JOIN dbo.UserInformation On (Owner.UserId = UserInformation.UserId) where (Email = '" + SessionEmail + "') ", con);
            rent.OwnerId = (int)SelectQuery1.ExecuteScalar();

            string InsertQuery = "insert into dbo.OwnerProperty(OwnerId,PropertyId) " + "values( @OwnerId,@PropertyId);";
            con.Execute(InsertQuery, new { rent.OwnerId, rent.PropertyId });
            rent.Facility = rent.AC + rent.Couch + rent.Refrigerator + rent.Wifi;
            string InsertQuery1 = "insert into dbo.PropertyFacility(PropertyId,Facility) " + "values(@PropertyId,@Facility);";
            
                con.Execute(InsertQuery1, new { rent.PropertyId, rent.Facility });
            
            return "Inserted";
        }
        public string AddValuesInPincode(Pincode Pin)
        {
            string InsertQuery = "insert into dbo.Pincode( AreaId, Value) " + "values( @AreaId, @Value);";
            con.Execute(InsertQuery, new { Pin.AreaId, Pin.Value });
            return "Inserted";
        }
        public string CheckSignIn(SignIn sign)
        {
            SqlCommand check_Email = new SqlCommand("SELECT Password FROM dbo.UserInformation WHERE (Email = '"  
                + sign.SignInEmail + "') ", con);
            con.Open();
            string PasswordVal = (string)check_Email.ExecuteScalar();
            VarForCheckSign = PasswordVal;
            return "Checked";
        }
        public IEnumerable<PropertyOfOwner> ShowListOfOwnerProperty()
        {
            string selectQuery = "SELECT Property.PropertyId, Property.Name as PropertyName, PropertyType.Name as PropertyType,HouseNumber,Bedroom,Hall,kitchen,Bathroom,City.Name as City,Area.Name as Area,Pincode.Value as Pincode,Facility,RentAmount from Property Inner Join OwnerProperty On(Property.PropertyId = OwnerProperty.PropertyId) Inner Join PropertyType On(Property.PropertyTypeId = PropertyType.PropertyTypeId)Inner Join Pincode On(Property.PincodeId = Pincode.PincodeId) Inner Join Area On(Pincode.AreaId = Area.AreaId)Inner Join City On(Area.CityId = City.CityId) Inner Join Owner On(OwnerProperty.OwnerId = Owner.OwnerId) Inner Join UserInformation On(Owner.UserId = UserInformation.UserId) Left Outer Join  PropertyFacility ON(property.PropertyId = PropertyFacility.PropertyId) where( Email = '" + SessionEmail + "'); ";
            return con.Query<PropertyOfOwner>(selectQuery);
        }
        public IEnumerable<Image> ShowImageOfOwnerProperty()
        {

            string selectQuery = "SELECT ImageName, Url FROM ImageOfProperty WHERE PropertyId =" + PropertyIdForImg;
           return con.Query<Image>(selectQuery);
        }

       /* public IEnumerable<Image> ShowImageOfOwnerProperty()
        {
            string selectQuery = "select * from ImageOfProperty WHERE ( PropertyId = '" + PropertyId + "')";
            return con.Query<Image>(selectQuery);
        }
        public IEnumerable<int> GetPropertyId()
        {
            string selectQuery = "  select  (Property.PropertyId) from Property Inner Join OwnerProperty On(Property.PropertyId = OwnerProperty.PropertyId) Inner Join Owner On(OwnerProperty.OwnerId = Owner.OwnerId) Inner Join UserInformation On(Owner.UserId = UserInformation.UserId)  where ( Email = '" + SessionEmail + "') ";
            return con.Query<int>(selectQuery);
        }*/
     

        public IEnumerable<Property> GetPropertyList()
        {
            string SelectQuery = " select Property.PropertyId, Property.Name as PropertyName from Property Inner Join OwnerProperty On(Property.PropertyId = OwnerProperty.PropertyId) Inner Join PropertyType On(Property.PropertyTypeId = PropertyType.PropertyTypeId) Inner Join Owner On(OwnerProperty.OwnerId =Owner.OwnerId) Inner Join UserInformation On(Owner.UserId = UserInformation.UserId) Left Outer Join  PropertyFacility ON(property.PropertyId = PropertyFacility.PropertyId) where (Email = '" + SessionEmail + "') ;";
            var SelectResult = con.Query<Property>(SelectQuery);
            return SelectResult;
        }
        public string InsertImage(ImageOfProperty Image)
        {
           // Image.PropertyId = PropertyIdInSql;
            string InsertQuery = "insert into dbo.ImageOfProperty(PropertyId,ImageName,Url) " + "values( @PropertyId,@ImageName,@Url);";
            con.Execute(InsertQuery, new { Image.PropertyId, Image.ImageName,Image.Url });
            return "Inserted";
        }
        
    }
}
